import React, { useState, useMemo } from "react";
import {
  Calendar, MessageCircle, BookOpen, ShieldCheck, Users, Smile,
  LogOut, ChevronRight, ChevronLeft, Check, CreditCard, Smartphone,
  Star, Plus, Video, MapPin, Clock, Lock, Fingerprint, Bell,
  ArrowRight, AlertCircle, Sparkles, ExternalLink, PartyPopper
} from "lucide-react";

/* ---------------------------------------------------------------
   TEND — a mental health care platform
   Visual direction takes inspiration from Headspace's general
   language — warm off-white over pure white, warm charcoal over
   black, one bold optimistic accent plus a lively supporting
   palette, big rounded pill buttons, flat friendly illustration —
   while using entirely original artwork, an original palette, and
   free Google fonts (Quicksand + Nunito), not Headspace's mascot,
   logo, or proprietary typeface.

   Functionally: patient onboarding + auto-matching, daily feed,
   appointment booking with a real Flutterwave-backed payment flow
   (Standard Checkout redirect + server-side verification, no card
   data ever touches this app), mood check-ins, journaling, and a
   professional-side console. See the companion /backend project.
----------------------------------------------------------------*/

const PALETTE = {
  paper: "#FBF3EA",
  card: "#FFFFFF",
  ink: "#2B2A28",
  inkSoft: "#847A71",
  primary: "#FF6B45",
  primaryDark: "#E8562E",
  primarySoft: "#FFE3D6",
  sun: "#FFC24B",
  sunDark: "#D99A2B",
  sunSoft: "#FFF1D3",
  berry: "#FF6FA5",
  berryDark: "#E14E86",
  berrySoft: "#FFE1EC",
  sky: "#2EC4B6",
  skyDark: "#219489",
  skySoft: "#D9F5F1",
  grape: "#7B5FE0",
  grapeDark: "#6247C4",
  grapeSoft: "#EAE2FB",
  leaf: "#48B37D",
  leafDark: "#399367",
  leafSoft: "#DEF3E7",
  line: "#F0E2D3",
};

const TONE_CYCLE = [PALETTE.primary, PALETTE.sky, PALETTE.grape, PALETTE.berry, PALETTE.leafDark, PALETTE.sunDark];

const CONCERNS = [
  "Anxiety", "Low mood", "Stress & burnout", "Relationships",
  "Grief & loss", "Trauma", "Sleep", "Self-esteem",
  "Substance use", "Work or school pressure",
];

const MOCK_PROFESSIONALS = [
  { id: "p1", name: "Dr. Amara Kintu", title: "Clinical Psychologist", license: "UAP-2291", years: 9, rating: 4.9, sessions: 1180,
    specialties: ["Anxiety", "Trauma", "Grief & loss", "Sleep"],
    modes: ["online", "physical"], rate: 120000,
    bio: "Works with adults carrying long-standing anxiety and trauma, using a slow, structured approach." },
  { id: "p2", name: "Michael Okello", title: "Licensed Counselor", license: "UAP-1074", years: 6, rating: 4.8, sessions: 860,
    specialties: ["Stress & burnout", "Work or school pressure", "Relationships", "Low mood"],
    modes: ["online", "physical"], rate: 90000,
    bio: "Helps working professionals and students untangle pressure before it becomes burnout." },
  { id: "p3", name: "Dr. Namono Grace", title: "Psychiatrist", license: "UAP-0562", years: 14, rating: 5.0, sessions: 2040,
    specialties: ["Low mood", "Trauma", "Substance use", "Anxiety"],
    modes: ["online"], rate: 150000,
    bio: "Combines talk therapy with medical oversight for more complex or long-running conditions." },
  { id: "p4", name: "Sarah Nabatanzi", title: "Marriage & Family Therapist", license: "UAP-1830", years: 5, rating: 4.7, sessions: 540,
    specialties: ["Relationships", "Grief & loss", "Self-esteem"],
    modes: ["online", "physical"], rate: 85000,
    bio: "Focuses on relationships — romantic, family, and the ones we have with ourselves." },
  { id: "p5", name: "David Mugisha", title: "Addiction Counselor", license: "UAP-2117", years: 8, rating: 4.8, sessions: 910,
    specialties: ["Substance use", "Stress & burnout", "Self-esteem"],
    modes: ["physical"], rate: 95000,
    bio: "Steady, non-judgemental support for recovery, one week at a time." },
  { id: "p6", name: "Grace Achieng", title: "Clinical Psychologist", license: "UAP-1955", years: 7, rating: 4.9, sessions: 770,
    specialties: ["Sleep", "Anxiety", "Work or school pressure", "Low mood"],
    modes: ["online", "physical"], rate: 100000,
    bio: "Specialises in the anxious mind that won't switch off at night." },
];

/* ---------------------------------------------------------------
   LIVE API CLIENT — talks to the real Tend backend (three Postgres
   databases, JWT auth, encrypted PHI fields, and now a real
   Flutterwave Standard Checkout payment flow). Flip USE_LIVE_API to
   true and point API_BASE_URL at a reachable deployment to connect
   this UI to it for real. This preview sandbox can't reach an
   outside server, so USE_LIVE_API defaults to false and everything
   runs on local mock state — every api.* call is still wired in and
   falls back to the same local behavior if a call fails or is off.
----------------------------------------------------------------*/
const USE_LIVE_API = false;
const API_BASE_URL = "http://localhost:4000";

let accessToken = null;

async function apiRequest(path, { method = "GET", body, auth = true } = {}) {
  const headers = { "Content-Type": "application/json" };
  if (auth && accessToken) headers.Authorization = `Bearer ${accessToken}`;
  const res = await fetch(`${API_BASE_URL}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

function normalizePro(p, index = 0) {
  return {
    id: p.id,
    name: p.full_name || p.name,
    title: p.title,
    license: p.license_number || p.license || "—",
    years: p.years_experience ?? p.years ?? 0,
    rating: Number(p.rating) || 0,
    sessions: p.sessions_completed ?? p.sessions ?? 0,
    specialties: p.specialties || [],
    modes: p.modes || [],
    rate: p.hourly_rate_ugx ?? p.rate ?? 0,
    bio: p.bio || "",
    tone: TONE_CYCLE[index % TONE_CYCLE.length],
  };
}

function normalizePost(p) {
  return { id: p.id, proId: p.professional_id, title: p.title, body: p.body, tag: p.tag, date: new Date(p.created_at).toLocaleDateString() };
}

const DEMO_PRO_LOGINS = {
  p1: "amara.kintu@tend.demo", p2: "michael.okello@tend.demo", p3: "grace.namono@tend.demo",
  p4: "sarah.nabatanzi@tend.demo", p5: "david.mugisha@tend.demo", p6: "grace.achieng@tend.demo",
};
const DEMO_PRO_PASSWORD = "Demo12345!";

const api = {
  setToken(token) { accessToken = token; },
  registerPatient: (payload) => apiRequest("/api/auth/register/patient", { method: "POST", body: payload, auth: false }),
  login: (email, password) => apiRequest("/api/auth/login", { method: "POST", body: { email, password }, auth: false }),
  getMyProfessional: () => apiRequest("/api/professionals/me"),
  listProfessionals: () => apiRequest("/api/professionals"),
  createAppointment: (body) => apiRequest("/api/appointments", { method: "POST", body }),
  // Real Flutterwave flow: initiate returns a hosted checkout link;
  // verify is only ever trusted once the backend has re-checked the
  // transaction directly with Flutterwave (see appointmentsService.js
  // / flutterwaveService.js in the backend project).
  initiatePayment: (id, method) => apiRequest(`/api/appointments/${id}/pay/initiate`, { method: "POST", body: { method } }),
  verifyPayment: (txRef, transactionId) => apiRequest("/api/appointments/pay/verify", { method: "POST", body: { txRef, transactionId } }),
  myAppointments: () => apiRequest("/api/appointments/mine"),
  listFeed: () => apiRequest("/api/feed"),
  postFeed: (body) => apiRequest("/api/feed", { method: "POST", body }),
  addMood: (body) => apiRequest("/api/patients/mood", { method: "POST", body }),
  listMood: () => apiRequest("/api/patients/mood"),
  addJournal: (body) => apiRequest("/api/patients/journal", { method: "POST", body }),
  listJournal: () => apiRequest("/api/patients/journal"),
};

const SLOTS = ["09:00", "11:30", "14:00", "16:30"];

function nextDays(n) {
  const out = [];
  const d = new Date();
  for (let i = 1; i <= n; i++) {
    const dd = new Date(d);
    dd.setDate(d.getDate() + i);
    out.push(dd);
  }
  return out;
}

function fmtDate(d) {
  return d.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" });
}

function ugx(n) {
  return "UGX " + n.toLocaleString();
}

function matchProfessionals(patient, pros = MOCK_PROFESSIONALS) {
  const scored = pros.map((pro) => {
    let score = 0;
    const overlap = pro.specialties.filter((s) => patient.concerns.includes(s));
    score += overlap.length * 3;
    if (patient.modePref === "either" || pro.modes.includes(patient.modePref)) score += 2;
    score += pro.rating;
    return { pro, score, overlap };
  });
  scored.sort((a, b) => b.score - a.score);
  const top = scored.slice(0, 3);
  const max = top[0]?.score || 1;
  return top.map((t) => ({ ...t, percent: Math.min(98, Math.round((t.score / (max + 3)) * 100)) }));
}

function initialsOf(name) {
  return name.split(" ").map((n) => n[0]).slice(-2).join("");
}

/* ============================= SHARED UI ============================= */

function GlobalStyle() {
  return (
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=Quicksand:wght@500;600;700&family=Nunito:wght@400;600;700;800&display=swap');
      * { box-sizing: border-box; }
      body { margin: 0; }
      ::selection { background: ${PALETTE.primarySoft}; }
      input:focus, select:focus, textarea:focus { outline: none; border-color: ${PALETTE.primary} !important; box-shadow: 0 0 0 3px ${PALETTE.primarySoft}; }
      .tend-btn-primary:hover { filter: brightness(1.04); transform: translateY(-1px); }
      .tend-btn-primary:active { transform: translateY(0); filter: brightness(0.97); }
      .tend-btn-ghost:hover { background: ${PALETTE.primarySoft}22; }
      .tend-card-hover:hover { box-shadow: 0 10px 24px -8px rgba(43,42,40,0.16); transform: translateY(-2px); }
      .tend-pill:hover { filter: brightness(0.98); }
      .tend-sidebar-item:hover { background: ${PALETTE.primarySoft}; }
    `}</style>
  );
}

// Simple, fully original rounded "blob" mark and character
// illustrations — no attempt to reproduce any brand's mascot.
function BlobMark({ size = 30 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" fill="none">
      <path d="M20 3C29.5 3 37 10.5 37 20C37 29.5 29.5 37 20 37C10.5 37 3 30.5 3 21C3 10 10.5 3 20 3Z" fill={PALETTE.primary} />
      <circle cx="15" cy="19" r="2.4" fill="#fff" />
      <circle cx="25" cy="19" r="2.4" fill="#fff" />
      <path d="M14 25C16 28 24 28 26 25" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" fill="none" />
    </svg>
  );
}

function Brand() {
  return (
    <div className="flex items-center gap-2">
      <BlobMark size={28} />
      <span style={{ fontFamily: "Quicksand, sans-serif", fontWeight: 700, fontSize: 22, color: PALETTE.ink }}>
        tend
      </span>
    </div>
  );
}

// A friendly floating blob character used decoratively (landing hero,
// empty states, success moments). Fully original geometry per call.
function BlobCharacter({ color = PALETTE.primary, size = 160, mood = "happy" }) {
  const mouthPath = mood === "sleepy" ? "M13 24C15 24 17 24 19 24" : mood === "calm" ? "M13 23C15 25.5 17 25.5 19 23" : "M12 22C14.5 26.5 17.5 26.5 20 22";
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none">
      <path d="M16 2C24 2 30 8.5 30 16.5C30 24.5 24 30 16 30C8 30 2 25 2 17C2 8.5 8 2 16 2Z" fill={color} />
      <circle cx="12" cy="15" r="1.7" fill="#fff" />
      <circle cx="20" cy="15" r="1.7" fill="#fff" />
      <path d={mouthPath} stroke="#fff" strokeWidth="1.6" strokeLinecap="round" fill="none" />
    </svg>
  );
}

function Dots({ colors }) {
  return (
    <>
      {colors.map((c, i) => (
        <circle key={i} r={5 + (i % 3) * 2} fill={c} />
      ))}
    </>
  );
}

function Pill({ active, onClick, tone = PALETTE.primary, children }) {
  return (
    <button
      onClick={onClick}
      className="tend-pill px-4 py-2 rounded-full text-sm font-bold transition"
      style={{
        background: active ? tone : PALETTE.card,
        color: active ? "#fff" : PALETTE.inkSoft,
        border: `2px solid ${active ? tone : PALETTE.line}`,
        fontFamily: "Nunito, sans-serif",
      }}
    >
      {children}
    </button>
  );
}

function Badge({ children, tone = PALETTE.primary, soft }) {
  return (
    <span
      className="text-xs font-bold px-2.5 py-1 rounded-full"
      style={{ background: soft || tone + "1f", color: tone, fontFamily: "Nunito, sans-serif" }}
    >
      {children}
    </span>
  );
}

function PrimaryButton({ children, onClick, disabled, full, icon: Icon, tone = PALETTE.primary }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`tend-btn-primary flex items-center justify-center gap-2 rounded-full px-6 py-3 text-sm font-extrabold transition ${full ? "w-full" : ""}`}
      style={{
        background: disabled ? PALETTE.line : tone,
        color: disabled ? PALETTE.inkSoft : "#fff",
        cursor: disabled ? "not-allowed" : "pointer",
        fontFamily: "Nunito, sans-serif",
        boxShadow: disabled ? "none" : `0 6px 16px -6px ${tone}99`,
      }}
    >
      {children} {Icon && <Icon size={16} />}
    </button>
  );
}

function GhostButton({ children, onClick, icon: Icon }) {
  return (
    <button
      onClick={onClick}
      className="tend-btn-ghost flex items-center justify-center gap-2 rounded-full px-6 py-3 text-sm font-extrabold transition"
      style={{ background: "transparent", color: PALETTE.ink, border: `2px solid ${PALETTE.ink}`, fontFamily: "Nunito, sans-serif" }}
    >
      {Icon && <Icon size={16} />} {children}
    </button>
  );
}

function Card({ children, tone, className = "", style = {} }) {
  return (
    <div
      className={`rounded-3xl ${className}`}
      style={{ background: tone || PALETTE.card, boxShadow: "0 4px 18px -10px rgba(43,42,40,0.14)", ...style }}
    >
      {children}
    </div>
  );
}

function Field({ label, children, hint }) {
  return (
    <label className="block mb-4">
      <div className="text-sm mb-1.5 font-bold" style={{ color: PALETTE.inkSoft, fontFamily: "Nunito, sans-serif" }}>{label}</div>
      {children}
      {hint && <div className="text-xs mt-1" style={{ color: PALETTE.inkSoft }}>{hint}</div>}
    </label>
  );
}

function inputStyle() {
  return { background: PALETTE.paper, border: `2px solid ${PALETTE.line}`, color: PALETTE.ink, fontFamily: "Nunito, sans-serif" };
}

function TextInput(props) {
  return (
    <input {...props} className={"w-full rounded-2xl px-4 py-2.5 text-sm outline-none " + (props.className || "")} style={{ ...inputStyle(), ...(props.style || {}) }} />
  );
}

function Select(props) {
  return (
    <select {...props} className="w-full rounded-2xl px-4 py-2.5 text-sm outline-none" style={inputStyle()}>
      {props.children}
    </select>
  );
}

function Avatar({ name, tone, size = 40 }) {
  return (
    <div
      className="rounded-full flex items-center justify-center shrink-0 font-extrabold"
      style={{ width: size, height: size, background: tone, color: "#fff", fontFamily: "Nunito, sans-serif", fontSize: size * 0.36 }}
    >
      {initialsOf(name)}
    </div>
  );
}

/* ============================= LANDING ============================= */

function Landing({ onPick }) {
  return (
    <div className="min-h-screen" style={{ background: PALETTE.paper }}>
      <div className="max-w-5xl mx-auto px-6 pt-8 pb-24">
        <Brand />
        <div className="grid md:grid-cols-2 gap-10 mt-16 items-center">
          <div>
            <h1 style={{ fontFamily: "Quicksand, sans-serif", fontWeight: 700, color: PALETTE.ink, lineHeight: 1.05 }} className="text-5xl md:text-6xl">
              Be kind to
              <br />your mind.
            </h1>
            <p className="mt-5 text-lg max-w-md" style={{ color: PALETTE.inkSoft, fontFamily: "Nunito, sans-serif" }}>
              Tend matches you with a licensed therapist who fits what you're carrying, then holds the rest — booking, secure payment, daily grounding, mood tracking, and a private journal — in one warm, simple place.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <PrimaryButton onClick={() => onPick("patient")} icon={ArrowRight}>Get started</PrimaryButton>
              <GhostButton onClick={() => onPick("professional")} icon={Users}>I'm a professional</GhostButton>
            </div>
            <div className="mt-10 flex gap-6">
              {[["6", "professionals", PALETTE.primary], ["3", "matches on signup", PALETTE.sky], ["2", "ways to meet", PALETTE.grape]].map(([n, label, c]) => (
                <div key={label} className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ background: c }} />
                  <div>
                    <div style={{ fontFamily: "Quicksand, sans-serif", fontWeight: 700, fontSize: 20, color: PALETTE.ink }}>{n}</div>
                    <div className="text-xs" style={{ color: PALETTE.inkSoft }}>{label}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <Card tone={PALETTE.primarySoft} className="p-8 relative overflow-hidden">
            <svg viewBox="0 0 40 20" className="absolute -top-2 -right-2 opacity-60" width="140">
              <Dots colors={[PALETTE.sun, PALETTE.sky, PALETTE.berry]} />
            </svg>
            <div className="flex justify-center py-4">
              <BlobCharacter color={PALETTE.primary} size={180} mood="happy" />
            </div>
            <Card tone={PALETTE.card} className="p-5 mt-2">
              <p className="text-sm" style={{ color: PALETTE.ink, fontFamily: "Nunito, sans-serif" }}>
                "The matching actually made sense — I didn't have to explain everything twice."
              </p>
              <p className="text-xs mt-2 font-bold" style={{ color: PALETTE.inkSoft }}>— a Tend member</p>
            </Card>
          </Card>
        </div>
      </div>
    </div>
  );
}

/* ============================= ONBOARDING ============================= */

function Onboarding({ onDone, onBack }) {
  const [step, setStep] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState(null);
  const [form, setForm] = useState({
    name: "", email: "", password: "", phone: "", dob: "", gender: "",
    concerns: [], modePref: "either", urgency: "routine",
    kin1: { name: "", relation: "", phone: "" },
    kin2: { name: "", relation: "", phone: "" },
  });

  const steps = ["About you", "What's going on", "Next of kin", "Your matches"];
  const stepColors = [PALETTE.primary, PALETTE.sky, PALETTE.grape, PALETTE.sun];

  const toggleConcern = (c) => {
    setForm((f) => ({ ...f, concerns: f.concerns.includes(c) ? f.concerns.filter((x) => x !== c) : [...f.concerns, c] }));
  };

  const matches = useMemo(() => matchProfessionals(form), [step]);

  const canNext = () => {
    if (step === 0) return form.name && form.email && form.password.length >= 10 && form.phone && form.dob;
    if (step === 1) return form.concerns.length > 0;
    if (step === 2) return form.kin1.name && form.kin1.phone && form.kin2.name && form.kin2.phone;
    return true;
  };

  const finish = async () => {
    setSubmitting(true);
    setSubmitError(null);
    if (USE_LIVE_API) {
      try {
        const res = await api.registerPatient({
          email: form.email, password: form.password, fullName: form.name,
          phone: form.phone, dateOfBirth: form.dob, gender: form.gender || undefined,
          concerns: form.concerns, modePref: form.modePref, urgency: form.urgency,
          nextOfKin: [form.kin1, form.kin2],
        });
        api.setToken(res.accessToken);
        const liveProfessionals = res.matches.map((m, i) => normalizePro(m.professional, i));
        const matchedIds = res.matches.map((m) => m.professionalId);
        setSubmitting(false);
        onDone({ ...form, id: res.patient.id }, matchedIds, liveProfessionals);
        return;
      } catch (err) {
        console.warn("Live registration failed, continuing in local demo mode:", err.message);
        setSubmitError("Couldn't reach the server — continuing with a local demo account.");
      }
    }
    setSubmitting(false);
    onDone(form, matches.map((m) => m.pro.id), null);
  };

  return (
    <div className="min-h-screen" style={{ background: PALETTE.paper }}>
      <div className="max-w-3xl mx-auto px-6 py-10">
        <div className="flex items-center justify-between">
          <Brand />
          <button onClick={onBack} className="text-sm font-bold" style={{ color: PALETTE.inkSoft }}>Exit</button>
        </div>

        <div className="flex items-center gap-3 mt-10 mb-8">
          {steps.map((s, i) => (
            <div key={s} className="flex items-center gap-3">
              <div
                className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-extrabold"
                style={{ background: i <= step ? stepColors[i] : PALETTE.card, color: i <= step ? "#fff" : PALETTE.inkSoft, border: `2px solid ${i <= step ? stepColors[i] : PALETTE.line}` }}
              >
                {i < step ? <Check size={14} /> : i + 1}
              </div>
              <span className="text-sm font-bold hidden md:inline" style={{ color: i === step ? PALETTE.ink : PALETTE.inkSoft, fontFamily: "Nunito, sans-serif" }}>{s}</span>
              {i < steps.length - 1 && <div className="w-8 h-0.5 rounded-full" style={{ background: PALETTE.line }} />}
            </div>
          ))}
        </div>

        <Card className="p-8">
          {step === 0 && (
            <div>
              <h2 style={{ fontFamily: "Quicksand, sans-serif", fontWeight: 700, fontSize: 26, color: PALETTE.ink }}>A little about you</h2>
              <p className="text-sm mt-1 mb-6" style={{ color: PALETTE.inkSoft }}>Only your care team will see this.</p>
              <div className="grid md:grid-cols-2 gap-x-4">
                <Field label="Full name"><TextInput value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Jane Nakato" /></Field>
                <Field label="Email"><TextInput type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="jane@email.com" /></Field>
                <Field label="Password" hint="At least 10 characters, with a number."><TextInput type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} placeholder="••••••••••" /></Field>
                <Field label="Phone number"><TextInput value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="+256 7XX XXX XXX" /></Field>
                <Field label="Date of birth"><TextInput type="date" value={form.dob} onChange={(e) => setForm({ ...form, dob: e.target.value })} /></Field>
                <Field label="Gender (optional)">
                  <Select value={form.gender} onChange={(e) => setForm({ ...form, gender: e.target.value })}>
                    <option value="">Prefer not to say</option><option>Woman</option><option>Man</option><option>Non-binary</option>
                  </Select>
                </Field>
              </div>
            </div>
          )}

          {step === 1 && (
            <div>
              <h2 style={{ fontFamily: "Quicksand, sans-serif", fontWeight: 700, fontSize: 26, color: PALETTE.ink }}>What's going on lately?</h2>
              <p className="text-sm mt-1 mb-5" style={{ color: PALETTE.inkSoft }}>Pick everything that fits — this is what we match on.</p>
              <div className="flex flex-wrap gap-2 mb-6">
                {CONCERNS.map((c, i) => (
                  <Pill key={c} active={form.concerns.includes(c)} tone={TONE_CYCLE[i % TONE_CYCLE.length]} onClick={() => toggleConcern(c)}>{c}</Pill>
                ))}
              </div>
              <div className="grid md:grid-cols-2 gap-x-4">
                <Field label="How would you like to meet?">
                  <Select value={form.modePref} onChange={(e) => setForm({ ...form, modePref: e.target.value })}>
                    <option value="either">Either is fine</option><option value="online">Online only</option><option value="physical">In person only</option>
                  </Select>
                </Field>
                <Field label="How urgent does this feel?">
                  <Select value={form.urgency} onChange={(e) => setForm({ ...form, urgency: e.target.value })}>
                    <option value="routine">Routine — no rush</option><option value="soon">I'd like to start soon</option><option value="urgent">I need support urgently</option>
                  </Select>
                </Field>
              </div>
              {form.urgency === "urgent" && (
                <div className="flex gap-2 items-start rounded-2xl p-4 text-sm" style={{ background: PALETTE.berrySoft, color: PALETTE.ink }}>
                  <AlertCircle size={16} className="mt-0.5 shrink-0" color={PALETTE.berryDark} />
                  If you're in immediate danger or thinking of harming yourself, please contact a local emergency line or crisis service right now, before booking through the app.
                </div>
              )}
            </div>
          )}

          {step === 2 && (
            <div>
              <h2 style={{ fontFamily: "Quicksand, sans-serif", fontWeight: 700, fontSize: 26, color: PALETTE.ink }}>Two people we can reach</h2>
              <p className="text-sm mt-1 mb-6" style={{ color: PALETTE.inkSoft }}>We only contact your next of kin in a safety emergency, never for routine updates.</p>
              {["kin1", "kin2"].map((k, i) => (
                <div key={k} className="mb-5 pb-5" style={{ borderBottom: i === 0 ? `2px solid ${PALETTE.line}` : "none" }}>
                  <div className="text-sm font-extrabold mb-2" style={{ color: PALETTE.ink }}>Next of kin {i + 1}</div>
                  <div className="grid md:grid-cols-3 gap-x-4">
                    <Field label="Name"><TextInput value={form[k].name} onChange={(e) => setForm({ ...form, [k]: { ...form[k], name: e.target.value } })} /></Field>
                    <Field label="Relationship"><TextInput value={form[k].relation} onChange={(e) => setForm({ ...form, [k]: { ...form[k], relation: e.target.value } })} placeholder="Sister, spouse…" /></Field>
                    <Field label="Phone number"><TextInput value={form[k].phone} onChange={(e) => setForm({ ...form, [k]: { ...form[k], phone: e.target.value } })} /></Field>
                  </div>
                </div>
              ))}
            </div>
          )}

          {step === 3 && (
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Sparkles size={18} color={PALETTE.sunDark} />
                <h2 style={{ fontFamily: "Quicksand, sans-serif", fontWeight: 700, fontSize: 26, color: PALETTE.ink }}>Your top 3 matches</h2>
              </div>
              <p className="text-sm mb-6" style={{ color: PALETTE.inkSoft }}>Based on what you shared, these professionals fit best. You can book any of them, or browse everyone later.</p>
              <div className="space-y-3">
                {matches.map(({ pro, percent, overlap }, i) => (
                  <Card key={pro.id} tone={PALETTE.paper} className="p-4 flex gap-4">
                    <Avatar name={pro.name} tone={TONE_CYCLE[i % TONE_CYCLE.length]} size={46} />
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <div><span style={{ color: PALETTE.ink }} className="font-extrabold">{pro.name}</span><span className="text-sm ml-2" style={{ color: PALETTE.inkSoft }}>{pro.title}</span></div>
                        <Badge tone={PALETTE.sunDark} soft={PALETTE.sunSoft}>{percent}% match</Badge>
                      </div>
                      <p className="text-sm mt-1" style={{ color: PALETTE.inkSoft }}>{pro.bio}</p>
                      <div className="flex flex-wrap gap-1.5 mt-2">{overlap.map((o) => <Badge key={o} tone={PALETTE.leafDark} soft={PALETTE.leafSoft}>{o}</Badge>)}</div>
                    </div>
                  </Card>
                ))}
              </div>
              {submitError && <div className="text-sm mt-4 font-bold" style={{ color: PALETTE.berryDark }}>{submitError}</div>}
            </div>
          )}

          <div className="flex justify-between mt-8">
            {step > 0 ? <GhostButton onClick={() => setStep(step - 1)} icon={ChevronLeft}>Back</GhostButton> : <span />}
            {step < 3
              ? <PrimaryButton disabled={!canNext()} onClick={() => setStep(step + 1)} icon={ChevronRight}>Continue</PrimaryButton>
              : <PrimaryButton disabled={submitting} onClick={finish} icon={ArrowRight}>{submitting ? "Setting things up…" : "Go to my dashboard"}</PrimaryButton>}
          </div>
        </Card>
      </div>
    </div>
  );
}

/* ============================= PATIENT DASHBOARD ============================= */

function Sidebar({ tabs, active, onChange, onExit, name, subtitle }) {
  return (
    <div className="w-64 shrink-0 h-screen sticky top-0 flex flex-col justify-between py-6 px-4" style={{ background: PALETTE.card, borderRight: `2px solid ${PALETTE.line}` }}>
      <div>
        <div className="px-2 mb-8"><Brand /></div>
        <div className="space-y-1.5">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => onChange(t.id)}
              className="tend-sidebar-item w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-sm font-extrabold transition"
              style={{ background: active === t.id ? PALETTE.primary : "transparent", color: active === t.id ? "#fff" : PALETTE.ink, fontFamily: "Nunito, sans-serif" }}
            >
              <t.icon size={18} /> {t.label}
            </button>
          ))}
        </div>
      </div>
      <div className="px-2">
        <div className="text-sm font-extrabold" style={{ color: PALETTE.ink }}>{name}</div>
        <div className="text-xs mb-3" style={{ color: PALETTE.inkSoft }}>{subtitle}</div>
        <button onClick={onExit} className="flex items-center gap-2 text-sm font-bold" style={{ color: PALETTE.inkSoft }}>
          <LogOut size={15} /> Switch role
        </button>
      </div>
    </div>
  );
}

const TAG_TONE = { Tip: PALETTE.sunDark, Exercise: PALETTE.skyDark, Reflection: PALETTE.grapeDark };

function FeedTab({ posts, setPosts, professionals }) {
  const [loaded, setLoaded] = React.useState(false);
  React.useEffect(() => {
    if (!USE_LIVE_API || loaded) return;
    api.listFeed()
      .then((rows) => { if (rows.length) setPosts(rows.map(normalizePost)); setLoaded(true); })
      .catch((err) => { console.warn("Feed fetch failed, showing local posts:", err.message); setLoaded(true); });
  }, [loaded]);

  return (
    <div className="max-w-2xl">
      <h1 style={{ fontFamily: "Quicksand, sans-serif", fontWeight: 700, fontSize: 30, color: PALETTE.ink }}>Daily feed</h1>
      <p className="text-sm mb-6" style={{ color: PALETTE.inkSoft }}>Grounded tips from your care team, posted as they come to mind.</p>
      <div className="space-y-3">
        {posts.map((post, i) => {
          const pro = professionals.find((p) => p.id === post.proId) || professionals[0];
          const tone = TAG_TONE[post.tag] || PALETTE.primary;
          return (
            <Card key={post.id} className="p-5" style={{ borderLeft: `6px solid ${tone}` }}>
              <div className="flex items-center gap-2 mb-1.5">
                <Avatar name={pro.name} tone={pro.tone || PALETTE.primary} size={26} />
                <span className="text-sm font-extrabold" style={{ color: PALETTE.ink }}>{pro.name}</span>
                <span className="text-xs" style={{ color: PALETTE.inkSoft }}>· {pro.title}</span>
                <Badge tone={tone}>{post.tag}</Badge>
              </div>
              <h3 className="text-lg font-bold" style={{ color: PALETTE.ink, fontFamily: "Quicksand, sans-serif" }}>{post.title}</h3>
              <p className="text-sm mt-1" style={{ color: PALETTE.inkSoft }}>{post.body}</p>
              <div className="text-xs mt-2 font-bold" style={{ color: PALETTE.inkSoft }}>{post.date}</div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

/* ---------------- Payment: real Flutterwave-backed flow ----------------
   1. Patient picks a method (this maps to Flutterwave's payment_options
      so the hosted page skips straight to the right tab).
   2. api.initiatePayment() asks the backend for a hosted checkout link
      — no card or mobile money details are ever collected here.
   3. In a real deployment the browser is sent to that link; this demo
      (no live Flutterwave key configured) gets back a `simulated: true`
      response instead, so it shows an inline stand-in for that hosted
      page — clearly labeled as a preview.
   4. Either way, confirmation only happens through api.verifyPayment(),
      which the backend re-checks against Flutterwave directly before
      ever marking the appointment confirmed. ------------------------- */
function PaymentPanel({ appointmentId, amount, onConfirmed, onCancel }) {
  const [method, setMethod] = useState("card");
  const [stage, setStage] = useState("choose"); // choose -> checking-out -> confirming
  const [checkout, setCheckout] = useState(null); // { link, txRef, simulated }
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);

  const startCheckout = async () => {
    setError(null);
    setBusy(true);
    if (USE_LIVE_API) {
      try {
        const res = await api.initiatePayment(appointmentId, method);
        setCheckout(res);
        setStage("checking-out");
        if (!res.simulated) window.open(res.link, "_blank", "noopener");
        setBusy(false);
        return;
      } catch (err) {
        setError("Couldn't reach the payment server — continuing with a local demo confirmation.");
      }
    }
    // Mock-mode / offline fallback so the flow always completes.
    setCheckout({ link: null, txRef: `local_${Date.now()}`, simulated: true });
    setStage("checking-out");
    setBusy(false);
  };

  const completePayment = async () => {
    setBusy(true);
    setError(null);
    if (USE_LIVE_API && checkout?.txRef && !checkout.txRef.startsWith("local_")) {
      try {
        await api.verifyPayment(checkout.txRef);
        setStage("done");
        setTimeout(() => onConfirmed(method), 900);
        return;
      } catch (err) {
        setError("We couldn't confirm that payment yet. If you completed it, this can take a few seconds — try again.");
        setBusy(false);
        return;
      }
    }
    setStage("done");
    setBusy(false);
    setTimeout(() => onConfirmed(method), 900);
  };

  return (
    <Card tone={PALETTE.paper} className="p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2" style={{ color: PALETTE.ink }}>
          <Lock size={15} /> <span className="text-sm font-extrabold">Secure checkout</span>
        </div>
        <span style={{ fontFamily: "Quicksand, sans-serif", fontWeight: 700, fontSize: 20, color: PALETTE.primaryDark }}>{ugx(amount)}</span>
      </div>

      {stage === "choose" && (
        <>
          <div className="flex gap-2 mb-5">
            <Pill active={method === "card"} onClick={() => setMethod("card")}><span className="flex items-center gap-1.5"><CreditCard size={14} /> Card</span></Pill>
            <Pill active={method === "momo"} onClick={() => setMethod("momo")}><span className="flex items-center gap-1.5"><Smartphone size={14} /> Mobile money</span></Pill>
          </div>
          <p className="text-xs mb-4" style={{ color: PALETTE.inkSoft }}>
            You'll finish this on Flutterwave's secure page — Tend never sees your card number or mobile money PIN.
          </p>
          {error && <div className="text-xs font-bold mb-3" style={{ color: PALETTE.berryDark }}>{error}</div>}
          <div className="flex gap-2">
            <GhostButton onClick={onCancel}>Cancel</GhostButton>
            <PrimaryButton disabled={busy} onClick={startCheckout} full icon={ExternalLink}>
              {busy ? "One moment…" : `Continue to pay ${ugx(amount)}`}
            </PrimaryButton>
          </div>
        </>
      )}

      {stage === "checking-out" && (
        <div>
          {checkout?.simulated ? (
            <Card tone={PALETTE.card} className="p-5 mb-4" style={{ border: `2px dashed ${PALETTE.line}` }}>
              <div className="flex items-center gap-2 mb-2">
                <Badge tone={PALETTE.grapeDark} soft={PALETTE.grapeSoft}>Preview</Badge>
                <span className="text-xs font-bold" style={{ color: PALETTE.inkSoft }}>Flutterwave's real hosted page will look different from this</span>
              </div>
              <p className="text-sm" style={{ color: PALETTE.ink }}>
                Standing in for Flutterwave's checkout — where a real deployment would collect the {method === "card" ? "card" : "mobile money"} details directly on their page.
              </p>
            </Card>
          ) : (
            <Card tone={PALETTE.card} className="p-5 mb-4">
              <p className="text-sm" style={{ color: PALETTE.ink }}>We opened Flutterwave's secure page in a new tab. Come back here once you've completed payment there.</p>
            </Card>
          )}
          {error && <div className="text-xs font-bold mb-3" style={{ color: PALETTE.berryDark }}>{error}</div>}
          <div className="flex gap-2">
            <GhostButton onClick={onCancel}>Cancel</GhostButton>
            <PrimaryButton disabled={busy} onClick={completePayment} full icon={Check}>
              {busy ? "Confirming…" : checkout?.simulated ? "Simulate successful payment" : "I've completed payment"}
            </PrimaryButton>
          </div>
        </div>
      )}

      {stage === "done" && (
        <div className="flex flex-col items-center py-4 text-center">
          <BlobCharacter color={PALETTE.leaf} size={90} mood="happy" />
          <div className="flex items-center gap-2 mt-3 font-extrabold" style={{ color: PALETTE.leafDark }}>
            <PartyPopper size={18} /> Payment confirmed
          </div>
        </div>
      )}
    </Card>
  );
}

function BookingTab({ patient, appointments, setAppointments, matchedIds, professionals }) {
  const [proId, setProId] = useState(matchedIds[0]);
  const [mode, setMode] = useState("online");
  const [day, setDay] = useState(null);
  const [slot, setSlot] = useState(null);
  const [reserving, setReserving] = useState(false);
  const [liveApptId, setLiveApptId] = useState(null);
  const [paying, setPaying] = useState(false);
  const [bookingError, setBookingError] = useState(null);
  const [filter, setFilter] = useState("matched");
  const [loadedHistory, setLoadedHistory] = useState(false);

  const pro = professionals.find((p) => p.id === proId);
  const list = filter === "matched" ? professionals.filter((p) => matchedIds.includes(p.id)) : professionals;
  const days = nextDays(6);

  React.useEffect(() => {
    if (!USE_LIVE_API || !patient.id || loadedHistory) return;
    api.myAppointments()
      .then((rows) => {
        setAppointments(rows.map((a) => ({
          id: a.id, proId: a.professional_id, mode: a.mode,
          date: new Date(a.scheduled_start).toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" }),
          time: new Date(a.scheduled_start).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" }),
          status: a.status, method: null, amount: a.amount_ugx, patientName: patient.name,
        })));
        setLoadedHistory(true);
      })
      .catch((err) => { console.warn("Appointment history fetch failed:", err.message); setLoadedHistory(true); });
  }, [loadedHistory, patient.id]);

  // Reserves the slot server-side (pending_payment) before payment ever
  // starts — mirrors the backend, which will not accept a payment for
  // an appointment that doesn't exist yet.
  const reserveAndPay = async () => {
    setBookingError(null);
    setReserving(true);
    if (USE_LIVE_API) {
      try {
        const scheduledStart = new Date(day);
        const [h, m] = slot.split(":").map(Number);
        scheduledStart.setHours(h, m, 0, 0);
        const appt = await api.createAppointment({ professionalId: proId, mode, scheduledStart: scheduledStart.toISOString() });
        setLiveApptId(appt.id);
      } catch (err) {
        console.warn("Live appointment reservation failed, continuing in local demo mode:", err.message);
        setBookingError("Couldn't reach the server — this booking will only be saved locally.");
      }
    }
    setReserving(false);
    setPaying(true);
  };

  const onConfirmed = (method) => {
    setAppointments((a) => [
      ...a,
      { id: liveApptId || Date.now(), proId, mode, date: fmtDate(day), time: slot, status: "confirmed", method, amount: pro.rate, patientName: patient.name },
    ]);
    setPaying(false); setDay(null); setSlot(null); setLiveApptId(null);
  };

  return (
    <div className="max-w-3xl">
      <h1 style={{ fontFamily: "Quicksand, sans-serif", fontWeight: 700, fontSize: 30, color: PALETTE.ink }}>Book a session</h1>
      <p className="text-sm mb-6" style={{ color: PALETTE.inkSoft }}>Choose a professional, a way to meet, and a time. Secure checkout confirms the slot.</p>

      {appointments.length > 0 && (
        <div className="mb-8 space-y-2">
          <div className="text-sm font-extrabold" style={{ color: PALETTE.ink }}>Your sessions</div>
          {appointments.map((a) => {
            const p = professionals.find((x) => x.id === a.proId);
            if (!p) return null;
            return (
              <Card key={a.id} className="flex items-center justify-between px-5 py-4">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: a.mode === "online" ? PALETTE.skySoft : PALETTE.berrySoft }}>
                    {a.mode === "online" ? <Video size={16} color={PALETTE.skyDark} /> : <MapPin size={16} color={PALETTE.berryDark} />}
                  </div>
                  <div>
                    <div className="text-sm font-bold" style={{ color: PALETTE.ink }}>{p.name} · {a.date} at {a.time}</div>
                    <div className="text-xs" style={{ color: PALETTE.inkSoft }}>{a.mode === "online" ? "Online session, in-app" : "In-person visit"}{a.method ? ` · paid via ${a.method === "card" ? "card" : "mobile money"}` : ""}</div>
                  </div>
                </div>
                <Badge tone={PALETTE.leafDark} soft={PALETTE.leafSoft}>{a.status === "confirmed" ? "Confirmed" : a.status}</Badge>
              </Card>
            );
          })}
        </div>
      )}

      <div className="flex gap-2 mb-3">
        <Pill active={filter === "matched"} onClick={() => setFilter("matched")}>Your matches</Pill>
        <Pill active={filter === "all"} tone={PALETTE.grape} onClick={() => setFilter("all")}>Everyone</Pill>
      </div>

      <div className="grid md:grid-cols-3 gap-3 mb-6">
        {list.map((p, i) => (
          <button key={p.id} onClick={() => { setProId(p.id); setDay(null); setSlot(null); }} className="text-left" style={{ display: "block" }}>
            <Card className="tend-card-hover p-4 transition" style={{ border: proId === p.id ? `2px solid ${PALETTE.primary}` : `2px solid transparent` }}>
              <Avatar name={p.name} tone={p.tone || TONE_CYCLE[i % TONE_CYCLE.length]} size={40} />
              <div className="text-sm font-extrabold mt-2" style={{ color: PALETTE.ink }}>{p.name}</div>
              <div className="text-xs" style={{ color: PALETTE.inkSoft }}>{p.title}</div>
              <div className="flex items-center gap-1 mt-1 text-xs font-bold" style={{ color: PALETTE.sunDark }}>
                <Star size={11} fill={PALETTE.sunDark} /> {p.rating} · {p.sessions} sessions
              </div>
              <div className="text-xs mt-1 font-bold" style={{ color: PALETTE.inkSoft }}>{ugx(p.rate)} / session</div>
            </Card>
          </button>
        ))}
      </div>

      {pro && (
        <Card className="p-5">
          <div className="flex gap-3 mb-4">
            {["online", "physical"].filter((m) => pro.modes.includes(m)).map((m) => (
              <Pill key={m} active={mode === m} tone={m === "online" ? PALETTE.sky : PALETTE.berry} onClick={() => setMode(m)}>
                <span className="flex items-center gap-1.5">{m === "online" ? <Video size={14} /> : <MapPin size={14} />} {m === "online" ? "Online" : "In person"}</span>
              </Pill>
            ))}
          </div>

          <div className="text-sm font-extrabold mb-2" style={{ color: PALETTE.ink }}>Choose a day</div>
          <div className="flex flex-wrap gap-2 mb-4">
            {days.map((d) => <Pill key={d.toString()} active={day?.toString() === d.toString()} onClick={() => { setDay(d); setSlot(null); }}>{fmtDate(d)}</Pill>)}
          </div>

          {day && (
            <>
              <div className="text-sm font-extrabold mb-2" style={{ color: PALETTE.ink }}>Choose a time</div>
              <div className="flex flex-wrap gap-2 mb-5">
                {SLOTS.map((s) => <Pill key={s} active={slot === s} tone={PALETTE.grape} onClick={() => setSlot(s)}><span className="flex items-center gap-1.5"><Clock size={13} /> {s}</span></Pill>)}
              </div>
            </>
          )}

          {bookingError && (
            <div className="flex gap-2 items-start rounded-2xl p-3 text-sm mb-3" style={{ background: PALETTE.berrySoft, color: PALETTE.ink }}>
              <AlertCircle size={16} className="mt-0.5 shrink-0" color={PALETTE.berryDark} /> {bookingError}
            </div>
          )}
          {slot && !paying && <PrimaryButton disabled={reserving} onClick={reserveAndPay}>{reserving ? "Reserving…" : `Continue to checkout · ${ugx(pro.rate)}`}</PrimaryButton>}
          {slot && paying && <PaymentPanel appointmentId={liveApptId} amount={pro.rate} onConfirmed={onConfirmed} onCancel={() => { setPaying(false); setLiveApptId(null); }} />}
        </Card>
      )}
    </div>
  );
}

const MOODS = [
  { v: 1, label: "Low", color: "#C25B6B" },
  { v: 2, label: "Down", color: PALETTE.sunDark },
  { v: 3, label: "Okay", color: PALETTE.sun },
  { v: 4, label: "Good", color: PALETTE.sky },
  { v: 5, label: "Great", color: PALETTE.primary },
];

function MoodTab({ entries, setEntries }) {
  const [val, setVal] = useState(null);
  const [note, setNote] = useState("");
  const [loaded, setLoaded] = React.useState(false);

  React.useEffect(() => {
    if (!USE_LIVE_API || loaded) return;
    api.listMood()
      .then((rows) => { if (rows.length) setEntries(rows.map((r) => ({ date: new Date(r.loggedAt).toLocaleDateString(), val: r.moodValue, note: r.note }))); setLoaded(true); })
      .catch((err) => { console.warn("Mood history fetch failed:", err.message); setLoaded(true); });
  }, [loaded]);

  const save = async () => {
    const entry = { date: new Date().toLocaleDateString(), val, note };
    setEntries((e) => [entry, ...e]);
    setVal(null); setNote("");
    if (USE_LIVE_API) {
      try { await api.addMood({ moodValue: entry.val, note: entry.note || undefined }); }
      catch (err) { console.warn("Saving mood check-in to the server failed, kept locally:", err.message); }
    }
  };

  return (
    <div className="max-w-2xl">
      <h1 style={{ fontFamily: "Quicksand, sans-serif", fontWeight: 700, fontSize: 30, color: PALETTE.ink }}>How are you, today?</h1>
      <p className="text-sm mb-6" style={{ color: PALETTE.inkSoft }}>One check-in a day is enough to notice a pattern.</p>

      <Card className="p-5 mb-8">
        <div className="flex gap-2 mb-4">
          {MOODS.map((m) => (
            <button key={m.v} onClick={() => setVal(m.v)}
              className="flex-1 rounded-2xl py-4 text-sm font-extrabold transition"
              style={{ background: val === m.v ? m.color : PALETTE.paper, color: val === m.v ? "#fff" : PALETTE.inkSoft, border: `2px solid ${val === m.v ? m.color : PALETTE.line}`, fontFamily: "Nunito, sans-serif" }}>
              {m.label}
            </button>
          ))}
        </div>
        <textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Anything behind that feeling? (optional)" rows={2}
          className="w-full rounded-2xl px-4 py-3 text-sm outline-none mb-3" style={inputStyle()} />
        <PrimaryButton disabled={!val} onClick={save} icon={Check}>Save today's check-in</PrimaryButton>
      </Card>

      {entries.length > 0 && (
        <div>
          <div className="text-sm font-extrabold mb-3" style={{ color: PALETTE.ink }}>Recent check-ins</div>
          <div className="space-y-2">
            {entries.slice(0, 10).map((e, i) => {
              const m = MOODS.find((x) => x.v === e.val);
              return (
                <div key={i} className="flex items-center gap-3">
                  <div className="w-3 h-3 rounded-full shrink-0" style={{ background: m.color }} />
                  <div className="flex-1">
                    <div className="text-sm font-bold" style={{ color: PALETTE.ink }}>{m.label} <span className="text-xs font-normal" style={{ color: PALETTE.inkSoft }}>· {e.date}</span></div>
                    {e.note && <div className="text-xs" style={{ color: PALETTE.inkSoft }}>{e.note}</div>}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

function JournalTab({ entries, setEntries }) {
  const [writing, setWriting] = useState(false);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [loaded, setLoaded] = React.useState(false);

  React.useEffect(() => {
    if (!USE_LIVE_API || loaded) return;
    api.listJournal()
      .then((rows) => { if (rows.length) setEntries(rows.map((r) => ({ id: r.id, title: r.title, body: r.body, date: new Date(r.createdAt).toLocaleDateString() }))); setLoaded(true); })
      .catch((err) => { console.warn("Journal history fetch failed:", err.message); setLoaded(true); });
  }, [loaded]);

  const save = async () => {
    if (!body.trim()) return;
    const entry = { id: Date.now(), title: title || "Untitled entry", body, date: new Date().toLocaleDateString() };
    setEntries((e) => [entry, ...e]);
    setTitle(""); setBody(""); setWriting(false);
    if (USE_LIVE_API) {
      try { await api.addJournal({ title: entry.title, body: entry.body }); }
      catch (err) { console.warn("Saving journal entry to the server failed, kept locally:", err.message); }
    }
  };

  return (
    <div className="max-w-2xl">
      <div className="flex items-center justify-between mb-1">
        <h1 style={{ fontFamily: "Quicksand, sans-serif", fontWeight: 700, fontSize: 30, color: PALETTE.ink }}>Journal</h1>
        {!writing && <PrimaryButton onClick={() => setWriting(true)} icon={Plus}>New entry</PrimaryButton>}
      </div>
      <p className="text-sm mb-6" style={{ color: PALETTE.inkSoft }}>Private — only visible to you, never shared with your care team automatically.</p>

      {writing && (
        <Card className="p-5 mb-6">
          <TextInput value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Title (optional)" className="mb-3" />
          <textarea value={body} onChange={(e) => setBody(e.target.value)} rows={6} placeholder="Write whatever's on your mind…"
            className="w-full rounded-2xl px-4 py-3 text-sm outline-none mb-3" style={inputStyle()} />
          <div className="flex gap-2"><GhostButton onClick={() => setWriting(false)}>Discard</GhostButton><PrimaryButton onClick={save}>Save entry</PrimaryButton></div>
        </Card>
      )}

      <div className="space-y-3">
        {entries.map((e) => (
          <Card key={e.id} className="p-5">
            <div className="flex items-center justify-between">
              <h3 className="font-bold" style={{ fontFamily: "Quicksand, sans-serif", fontSize: 18, color: PALETTE.ink }}>{e.title}</h3>
              <span className="text-xs font-bold" style={{ color: PALETTE.inkSoft }}>{e.date}</span>
            </div>
            <p className="text-sm mt-1 whitespace-pre-wrap" style={{ color: PALETTE.inkSoft }}>{e.body}</p>
          </Card>
        ))}
        {entries.length === 0 && !writing && <p className="text-sm" style={{ color: PALETTE.inkSoft }}>Nothing here yet — your first entry is one click away.</p>}
      </div>
    </div>
  );
}

function CareTeamTab({ matchedIds, professionals }) {
  return (
    <div className="max-w-2xl">
      <h1 style={{ fontFamily: "Quicksand, sans-serif", fontWeight: 700, fontSize: 30, color: PALETTE.ink }}>Your care team</h1>
      <p className="text-sm mb-6" style={{ color: PALETTE.inkSoft }}>Matched to you when you signed up.</p>
      <div className="space-y-3">
        {matchedIds.map((id, i) => {
          const p = professionals.find((x) => x.id === id);
          if (!p) return null;
          return (
            <Card key={id} className="p-5 flex gap-4">
              <Avatar name={p.name} tone={p.tone || TONE_CYCLE[i % TONE_CYCLE.length]} size={50} />
              <div>
                <div style={{ color: PALETTE.ink }} className="font-extrabold">{p.name}</div>
                <div className="text-xs font-bold" style={{ color: PALETTE.inkSoft }}>{p.title} · License {p.license} · {p.years} yrs experience</div>
                <p className="text-sm mt-1" style={{ color: PALETTE.inkSoft }}>{p.bio}</p>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

function SecurityTab() {
  const [twoFA, setTwoFA] = useState(true);
  const [biometric, setBiometric] = useState(false);
  const [sessions, setSessions] = useState([
    { device: "This device · Chrome, Kampala", time: "Active now" },
    { device: "iPhone 13 · Tend app", time: "2 days ago" },
  ]);

  const Toggle = ({ on, onClick }) => (
    <button onClick={onClick} className="w-11 h-6 rounded-full relative transition" style={{ background: on ? PALETTE.primary : PALETTE.line }}>
      <span className="absolute top-0.5 w-5 h-5 rounded-full bg-white transition" style={{ left: on ? 20 : 2 }} />
    </button>
  );

  const rows = [
    { icon: ShieldCheck, tone: PALETTE.primary, title: "Two-factor authentication", sub: "Require a code by SMS at login", on: twoFA, toggle: () => setTwoFA(!twoFA) },
    { icon: Fingerprint, tone: PALETTE.grape, title: "Biometric app lock", sub: "Face or fingerprint to reopen the app", on: biometric, toggle: () => setBiometric(!biometric) },
    { icon: Bell, tone: PALETTE.berry, title: "Alert next of kin on flagged risk", sub: "Only in a safety emergency, reviewed by a clinician first", on: true, toggle: () => {} },
  ];

  return (
    <div className="max-w-2xl">
      <h1 style={{ fontFamily: "Quicksand, sans-serif", fontWeight: 700, fontSize: 30, color: PALETTE.ink }}>Privacy & security</h1>
      <p className="text-sm mb-6" style={{ color: PALETTE.inkSoft }}>Session notes, mood data, and payment details are encrypted separately from your everyday login.</p>

      <div className="space-y-2">
        {rows.map((r) => (
          <Card key={r.title} className="flex items-center justify-between p-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: r.tone + "1f" }}><r.icon size={17} color={r.tone} /></div>
              <div><div className="text-sm font-extrabold" style={{ color: PALETTE.ink }}>{r.title}</div><div className="text-xs" style={{ color: PALETTE.inkSoft }}>{r.sub}</div></div>
            </div>
            <Toggle on={r.on} onClick={r.toggle} />
          </Card>
        ))}
      </div>

      <div className="text-sm font-extrabold mt-6 mb-2" style={{ color: PALETTE.ink }}>Signed-in devices</div>
      <div className="space-y-2">
        {sessions.map((s, i) => (
          <Card key={i} className="flex items-center justify-between px-5 py-4">
            <div><div className="text-sm font-bold" style={{ color: PALETTE.ink }}>{s.device}</div><div className="text-xs" style={{ color: PALETTE.inkSoft }}>{s.time}</div></div>
            {s.time !== "Active now" && <button onClick={() => setSessions(sessions.filter((_, j) => j !== i))} className="text-xs font-extrabold" style={{ color: PALETTE.berryDark }}>Sign out</button>}
          </Card>
        ))}
      </div>
    </div>
  );
}

function PatientDashboard({ patient, matchedIds, professionals, onExit, sharedState }) {
  const [tab, setTab] = useState("feed");
  const tabs = [
    { id: "feed", label: "Daily feed", icon: MessageCircle },
    { id: "book", label: "Sessions", icon: Calendar },
    { id: "mood", label: "Mood check-in", icon: Smile },
    { id: "journal", label: "Journal", icon: BookOpen },
    { id: "team", label: "Care team", icon: Users },
    { id: "security", label: "Privacy & security", icon: ShieldCheck },
  ];
  return (
    <div className="flex" style={{ background: PALETTE.paper, minHeight: "100vh" }}>
      <Sidebar tabs={tabs} active={tab} onChange={setTab} onExit={onExit} name={patient.name} subtitle="Patient" />
      <div className="flex-1 p-10">
        {tab === "feed" && <FeedTab posts={sharedState.posts} setPosts={sharedState.setPosts} professionals={professionals} />}
        {tab === "book" && <BookingTab patient={patient} appointments={sharedState.appointments} setAppointments={sharedState.setAppointments} matchedIds={matchedIds} professionals={professionals} />}
        {tab === "mood" && <MoodTab entries={sharedState.moods} setEntries={sharedState.setMoods} />}
        {tab === "journal" && <JournalTab entries={sharedState.journal} setEntries={sharedState.setJournal} />}
        {tab === "team" && <CareTeamTab matchedIds={matchedIds} professionals={professionals} />}
        {tab === "security" && <SecurityTab />}
      </div>
    </div>
  );
}

/* ============================= PROFESSIONAL SIDE ============================= */

function ProfessionalPicker({ professionals, onPick, onBack }) {
  const [signingIn, setSigningIn] = useState(null);
  const [error, setError] = useState(null);

  const pick = async (p) => {
    setError(null);
    if (USE_LIVE_API && DEMO_PRO_LOGINS[p.id]) {
      setSigningIn(p.id);
      try {
        const res = await api.login(DEMO_PRO_LOGINS[p.id], DEMO_PRO_PASSWORD);
        api.setToken(res.accessToken);
      } catch (err) {
        console.warn("Live professional login failed, continuing in local demo mode:", err.message);
        setError("Couldn't reach the server — continuing with a local demo session.");
      }
      setSigningIn(null);
    }
    onPick(p.id);
  };

  return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: PALETTE.paper }}>
      <div className="max-w-md w-full">
        <Brand />
        <h2 className="mt-8 mb-1" style={{ fontFamily: "Quicksand, sans-serif", fontWeight: 700, fontSize: 26, color: PALETTE.ink }}>Continue as</h2>
        <p className="text-sm mb-6" style={{ color: PALETTE.inkSoft }}>Demo login — pick a certified professional profile.</p>
        {error && <p className="text-xs font-bold mb-3" style={{ color: PALETTE.berryDark }}>{error}</p>}
        <div className="space-y-2">
          {professionals.slice(0, 3).map((p, i) => (
            <button key={p.id} disabled={signingIn === p.id} onClick={() => pick(p)} className="w-full text-left" style={{ opacity: signingIn === p.id ? 0.6 : 1 }}>
              <Card className="tend-card-hover flex items-center gap-3 p-4 transition">
                <Avatar name={p.name} tone={p.tone || TONE_CYCLE[i % TONE_CYCLE.length]} size={44} />
                <div><div className="text-sm font-extrabold" style={{ color: PALETTE.ink }}>{p.name}</div><div className="text-xs" style={{ color: PALETTE.inkSoft }}>{p.title} · Verified · License {p.license}</div></div>
                <ChevronRight size={16} className="ml-auto" color={PALETTE.inkSoft} />
              </Card>
            </button>
          ))}
        </div>
        <button onClick={onBack} className="text-sm font-bold mt-6" style={{ color: PALETTE.inkSoft }}>Back</button>
      </div>
    </div>
  );
}

function ProDashboard({ proId, professionals, onExit, sharedState }) {
  const [tab, setTab] = useState("requests");
  const pro = professionals.find((p) => p.id === proId);
  const [postTitle, setPostTitle] = useState("");
  const [postBody, setPostBody] = useState("");
  const [postTag, setPostTag] = useState("Tip");
  const [liveAppointments, setLiveAppointments] = useState(null);
  const [loadedAppts, setLoadedAppts] = useState(false);

  const tabs = [
    { id: "requests", label: "Sessions", icon: Calendar },
    { id: "feed", label: "Post to feed", icon: MessageCircle },
    { id: "profile", label: "Profile & credentials", icon: ShieldCheck },
  ];

  React.useEffect(() => {
    if (!USE_LIVE_API || loadedAppts) return;
    api.myAppointments()
      .then((rows) => {
        setLiveAppointments(rows.map((a) => ({
          id: a.id, mode: a.mode,
          date: new Date(a.scheduled_start).toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" }),
          time: new Date(a.scheduled_start).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" }),
          amount: a.amount_ugx, patientName: `Patient ${a.patient_id.slice(0, 8)}`,
        })));
        setLoadedAppts(true);
      })
      .catch((err) => { console.warn("Professional appointment fetch failed, showing local bookings:", err.message); setLoadedAppts(true); });
  }, [loadedAppts]);

  const myAppointments = liveAppointments ?? sharedState.appointments.filter((a) => a.proId === proId);

  const publish = async () => {
    if (!postBody.trim()) return;
    const localPost = { id: Date.now(), proId, title: postTitle || "A note for today", body: postBody, tag: postTag, date: new Date().toLocaleDateString() };
    if (USE_LIVE_API) {
      try {
        const saved = await api.postFeed({ title: localPost.title, body: localPost.body, tag: localPost.tag });
        sharedState.setPosts((p) => [normalizePost(saved), ...p]);
        setPostTitle(""); setPostBody("");
        return;
      } catch (err) { console.warn("Publishing to the live feed failed, saving locally instead:", err.message); }
    }
    sharedState.setPosts((p) => [localPost, ...p]);
    setPostTitle(""); setPostBody("");
  };

  return (
    <div className="flex" style={{ background: PALETTE.paper, minHeight: "100vh" }}>
      <Sidebar tabs={tabs} active={tab} onChange={setTab} onExit={onExit} name={pro.name} subtitle="Professional" />
      <div className="flex-1 p-10">
        {tab === "requests" && (
          <div className="max-w-2xl">
            <h1 style={{ fontFamily: "Quicksand, sans-serif", fontWeight: 700, fontSize: 30, color: PALETTE.ink }}>Sessions</h1>
            <p className="text-sm mb-6" style={{ color: PALETTE.inkSoft }}>Paid and confirmed bookings appear here automatically.</p>
            {myAppointments.length === 0 && <p className="text-sm" style={{ color: PALETTE.inkSoft }}>No bookings yet — patients matched to you will see you first when they book.</p>}
            <div className="space-y-2">
              {myAppointments.map((a) => (
                <Card key={a.id} className="flex items-center justify-between px-5 py-4">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: a.mode === "online" ? PALETTE.skySoft : PALETTE.berrySoft }}>
                      {a.mode === "online" ? <Video size={16} color={PALETTE.skyDark} /> : <MapPin size={16} color={PALETTE.berryDark} />}
                    </div>
                    <div><div className="text-sm font-bold" style={{ color: PALETTE.ink }}>{a.patientName} · {a.date} at {a.time}</div><div className="text-xs" style={{ color: PALETTE.inkSoft }}>{ugx(a.amount)} received · {a.mode === "online" ? "online session" : "in person"}</div></div>
                  </div>
                  <Badge tone={PALETTE.leafDark} soft={PALETTE.leafSoft}>Paid & confirmed</Badge>
                </Card>
              ))}
            </div>
          </div>
        )}

        {tab === "feed" && (
          <div className="max-w-xl">
            <h1 style={{ fontFamily: "Quicksand, sans-serif", fontWeight: 700, fontSize: 30, color: PALETTE.ink }}>Post to the daily feed</h1>
            <p className="text-sm mb-6" style={{ color: PALETTE.inkSoft }}>Short, practical notes reach every patient matched to you.</p>
            <Card className="p-5">
              <div className="flex gap-2 mb-3">
                {["Tip", "Exercise", "Reflection"].map((t) => <Pill key={t} active={postTag === t} tone={TAG_TONE[t]} onClick={() => setPostTag(t)}>{t}</Pill>)}
              </div>
              <TextInput value={postTitle} onChange={(e) => setPostTitle(e.target.value)} placeholder="Title" className="mb-3" />
              <textarea value={postBody} onChange={(e) => setPostBody(e.target.value)} rows={4} placeholder="Write your note…" className="w-full rounded-2xl px-4 py-3 text-sm outline-none mb-3" style={inputStyle()} />
              <PrimaryButton onClick={publish} icon={Plus}>Publish to feed</PrimaryButton>
            </Card>
          </div>
        )}

        {tab === "profile" && (
          <div className="max-w-xl">
            <h1 style={{ fontFamily: "Quicksand, sans-serif", fontWeight: 700, fontSize: 30, color: PALETTE.ink }}>Profile & credentials</h1>
            <Card className="p-5 mt-6">
              <div className="flex items-center gap-2 mb-3"><ShieldCheck size={16} color={PALETTE.leafDark} /><Badge tone={PALETTE.leafDark} soft={PALETTE.leafSoft}>Verified professional</Badge></div>
              <div className="text-sm font-extrabold" style={{ color: PALETTE.ink }}>{pro.name}</div>
              <div className="text-xs mb-3" style={{ color: PALETTE.inkSoft }}>{pro.title} · License {pro.license} · {pro.years} years practicing</div>
              <div className="flex flex-wrap gap-1.5 mb-3">{pro.specialties.map((s, i) => <Badge key={s} tone={TONE_CYCLE[i % TONE_CYCLE.length]}>{s}</Badge>)}</div>
              <p className="text-sm" style={{ color: PALETTE.inkSoft }}>{pro.bio}</p>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}

/* ============================= APP ROOT ============================= */

export default function App() {
  const [screen, setScreen] = useState("landing");
  const [patient, setPatient] = useState(null);
  const [matchedIds, setMatchedIds] = useState([]);
  const [proId, setProId] = useState(null);
  const [professionals, setProfessionals] = useState(MOCK_PROFESSIONALS.map((p, i) => ({ ...p, tone: TONE_CYCLE[i % TONE_CYCLE.length] })));

  const [posts, setPosts] = useState([
    { id: 1, proId: "p2", title: "Naming the pressure helps", tag: "Tip", date: "2 days ago",
      body: "Before a hard day, write down the one thing you're most worried about. It rarely looks as big on paper." },
    { id: 2, proId: "p1", title: "A 4-count breath for racing thoughts", tag: "Exercise", date: "4 days ago",
      body: "Inhale for 4, hold for 4, exhale for 6. Repeat five times before you reach for your phone in the morning." },
  ]);
  const [appointments, setAppointments] = useState([]);
  const [moods, setMoods] = useState([]);
  const [journal, setJournal] = useState([]);

  const sharedState = { posts, setPosts, appointments, setAppointments, moods, setMoods, journal, setJournal };

  return (
    <div style={{ fontFamily: "Nunito, sans-serif" }}>
      <GlobalStyle />

      {screen === "landing" && <Landing onPick={(role) => setScreen(role === "patient" ? "onboarding" : "pro-pick")} />}

      {screen === "onboarding" && (
        <Onboarding
          onBack={() => setScreen("landing")}
          onDone={(form, ids, liveProfessionals) => {
            setPatient(form);
            setMatchedIds(ids);
            if (liveProfessionals?.length) {
              setProfessionals((prev) => {
                const byId = new Map(prev.map((p) => [p.id, p]));
                liveProfessionals.forEach((p) => byId.set(p.id, p));
                return Array.from(byId.values());
              });
            }
            setScreen("patient-dash");
          }}
        />
      )}

      {screen === "patient-dash" && patient && (
        <PatientDashboard patient={patient} matchedIds={matchedIds} professionals={professionals} onExit={() => setScreen("landing")} sharedState={sharedState} />
      )}

      {screen === "pro-pick" && (
        <ProfessionalPicker professionals={professionals} onBack={() => setScreen("landing")} onPick={(id) => { setProId(id); setScreen("pro-dash"); }} />
      )}

      {screen === "pro-dash" && proId && (
        <ProDashboard proId={proId} professionals={professionals} onExit={() => setScreen("landing")} sharedState={sharedState} />
      )}
    </div>
  );
}
